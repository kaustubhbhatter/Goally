
export const getDueDateStatus = (dueDate: string | undefined): 'past' | 'this-week' | 'future' | null => {
  if (!dueDate) return null;

  const today = new Date();
  today.setHours(0, 0, 0, 0); // Normalize today to the start of the day for accurate comparison.

  // The input type="date" returns 'YYYY-MM-DD', which JS new Date() interprets as UTC midnight.
  // To avoid timezone issues where the date could be a day off, we parse it manually.
  const [year, month, day] = dueDate.split('-').map(Number);
  const dueDateLocal = new Date(year, month - 1, day);

  if (dueDateLocal.getTime() < today.getTime()) {
    return 'past';
  }

  const oneWeekFromToday = new Date(today);
  oneWeekFromToday.setDate(today.getDate() + 7);

  if (dueDateLocal.getTime() <= oneWeekFromToday.getTime()) {
    return 'this-week';
  }

  return 'future';
};
