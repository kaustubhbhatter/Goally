
import React, { useState } from 'react';
import { Initiative, KR } from '../types';
import { Priority, Status, priorityLabel } from '../constants';
import { triggerConfetti } from '../utils/animations';
import { getDueDateStatus } from '../utils/dateUtils';

interface InitiativeCardProps {
  initiative: Initiative;
  kr: KR;
  onUpdate: (updatedKr: KR) => void;
  onDelete: (initiativeId: string) => void;
}

const CalendarIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
    </svg>
);
const PencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
        <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
    </svg>
);
const SaveIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
    </svg>
);
const CancelIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);


const InitiativeCard: React.FC<InitiativeCardProps> = ({ initiative, kr, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedInitiative, setEditedInitiative] = useState(initiative);

  const handleStatusChange = (newStatus: Status) => {
    const updatedInitiatives = kr.initiatives.map(i =>
      i.id === initiative.id ? { ...i, status: newStatus } : i
    );
    onUpdate({ ...kr, initiatives: updatedInitiatives });
  };

  const handleSave = () => {
    const updatedInitiatives = kr.initiatives.map(i =>
      i.id === initiative.id ? editedInitiative : i
    );
    onUpdate({ ...kr, initiatives: updatedInitiatives });
    setIsEditing(false);
  };
  
  const handleCancel = () => {
    setEditedInitiative(initiative);
    setIsEditing(false);
  };

  const priorityColorClass = {
    [Priority.High]: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    [Priority.Medium]: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    [Priority.Low]: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  };

  const dueDateStatus = getDueDateStatus(initiative.dueDate);
  const dueDateColorClass = {
      'past': 'text-red-500 dark:text-red-400',
      'this-week': 'text-yellow-600 dark:text-yellow-400',
      'future': 'text-slate-500 dark:text-slate-400',
  }
  
  const handleToggleInProgress = () => {
      const newStatus = initiative.status === Status.NotStarted ? Status.InProgress : Status.NotStarted;
      handleStatusChange(newStatus);
  };
  
  const handleToggleCompleted = () => {
      const newStatus = initiative.status === Status.Completed ? Status.InProgress : Status.Completed;
      if (newStatus === Status.Completed) {
        triggerConfetti();
      }
      handleStatusChange(newStatus);
  };

  if (isEditing) {
    return (
        <div className="p-3 bg-slate-100 dark:bg-slate-700 rounded-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <input 
                type="text"
                value={editedInitiative.description}
                onChange={(e) => setEditedInitiative({...editedInitiative, description: e.target.value})}
                className="flex-1 w-full sm:w-auto px-2 py-1 border border-slate-300 dark:border-slate-500 rounded-md bg-white dark:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <div className="flex items-center gap-3">
                 <input
                    type="date"
                    value={editedInitiative.dueDate || ''}
                    onChange={(e) => setEditedInitiative({ ...editedInitiative, dueDate: e.target.value })}
                    className="bg-white dark:bg-slate-600 border border-slate-300 dark:border-slate-500 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <select
                    value={editedInitiative.priority}
                    onChange={(e) => setEditedInitiative({...editedInitiative, priority: Number(e.target.value) as Priority})}
                    className="bg-white dark:bg-slate-600 border border-slate-300 dark:border-slate-500 rounded-md px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                    <option value={Priority.Low}>Low</option>
                    <option value={Priority.Medium}>Medium</option>
                    <option value={Priority.High}>High</option>
                </select>
                <button onClick={handleSave} className="text-green-500 hover:text-green-600 p-1 rounded-full hover:bg-green-100 dark:hover:bg-green-900/50"><SaveIcon /></button>
                <button onClick={handleCancel} className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"><CancelIcon /></button>
            </div>
        </div>
    );
  }

  return (
    <div className={`p-3 bg-slate-100 dark:bg-slate-700 rounded-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 transition-opacity duration-300 ${initiative.status === Status.Completed ? 'opacity-60' : ''}`}>
      <p className={`flex-1 text-slate-700 dark:text-slate-300 ${initiative.status === Status.Completed ? 'line-through' : ''}`}>{initiative.description}</p>
      <div className="flex items-center gap-2 sm:gap-4">
        {initiative.dueDate && (
            <div className={`flex items-center text-xs font-medium ${dueDateStatus && dueDateColorClass[dueDateStatus]}`}>
                <CalendarIcon />
                {new Date(initiative.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })}
            </div>
        )}
        <span className={`px-2 py-1 text-xs font-medium rounded-full ${priorityColorClass[initiative.priority]}`}>
          {priorityLabel[initiative.priority]}
        </span>
        
        <div className="flex items-center gap-1">
            {initiative.status !== Status.Completed && (
                 <button onClick={handleToggleInProgress} className={`px-2 py-1 text-xs rounded-md transition-colors ${initiative.status === Status.InProgress ? 'bg-purple-200 text-purple-800 dark:bg-purple-900 dark:text-purple-300' : 'bg-slate-200 text-slate-600 dark:bg-slate-600 dark:text-slate-300'}`}>
                    {initiative.status === Status.InProgress ? 'In Progress' : 'Not Started'}
                </button>
            )}
             <button onClick={handleToggleCompleted} className={`p-1.5 rounded-full transition-colors ${initiative.status === Status.Completed ? 'text-green-500 bg-green-100 dark:bg-green-900' : 'text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-600'}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
            </button>
        </div>

        <div className="flex items-center">
            <button onClick={() => setIsEditing(true)} className="text-slate-400 hover:text-purple-500 dark:hover:text-purple-400 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                <PencilIcon />
            </button>
            <button onClick={() => onDelete(initiative.id)} className="text-slate-400 hover:text-red-500 dark:hover:text-red-400 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
                </svg>
            </button>
        </div>
      </div>
    </div>
  );
};

export default InitiativeCard;