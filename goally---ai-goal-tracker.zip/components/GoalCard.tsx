
import React, { useState, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'react-hot-toast';
import { Goal, KR, Initiative } from '../types';
import { Status } from '../constants';
import KRCard from './KRCard';
import ProgressBar from './ProgressBar';
import Modal from './Modal';

interface GoalCardProps {
  goal: Goal;
  onUpdate: (updatedGoal: Goal) => void;
  onDelete: (goalId: string) => void;
}

const PencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L14.732 3.732z" />
    </svg>
);
const SaveIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
    </svg>
);
const CancelIcon = () => (
     <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
    </svg>
);


const GoalCard: React.FC<GoalCardProps> = ({ goal, onUpdate, onDelete }) => {
  const [isKrModalOpen, setIsKrModalOpen] = useState(false);
  const [newKrDesc, setNewKrDesc] = useState('');
  const [newKrWeightage, setNewKrWeightage] = useState(0);
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(goal.title);

  const calculateKRProgress = (initiatives: Initiative[]): number => {
    const totalPriority = initiatives.reduce((sum, i) => sum + i.priority, 0);
    if (totalPriority === 0) return 0;
    const completedPriority = initiatives
      .filter(i => i.status === Status.Completed)
      .reduce((sum, i) => sum + i.priority, 0);
    return (completedPriority / totalPriority) * 100;
  };

  const calculateGoalProgress = (krs: KR[]): number => {
    if (krs.length === 0) return 0;
    const totalProgress = krs.reduce((sum, kr) => {
      const krProgress = calculateKRProgress(kr.initiatives);
      return sum + (krProgress * (kr.weightage / 100));
    }, 0);
    return totalProgress;
  };

  const progress = useMemo(() => calculateGoalProgress(goal.krs), [goal.krs]);

  const remainingWeightage = 100 - goal.krs.reduce((sum, kr) => sum + kr.weightage, 0);

  const handleAddKR = () => {
    if (newKrDesc.trim() === '') {
        toast.error('Key Result description cannot be empty.');
        return;
    }
    if (newKrWeightage <= 0 || newKrWeightage > remainingWeightage) {
        toast.error(`Please enter a weightage between 1 and ${remainingWeightage}%.`);
        return;
    }

    const newKR: KR = {
      id: uuidv4(),
      description: newKrDesc,
      weightage: newKrWeightage,
      initiatives: [],
    };
    onUpdate({ ...goal, krs: [...goal.krs, newKR] });
    setNewKrDesc('');
    setNewKrWeightage(0);
    setIsKrModalOpen(false);
  };

  const handleDeleteKR = (krId: string) => {
      const updatedKrs = goal.krs.filter(k => k.id !== krId);
      onUpdate({ ...goal, krs: updatedKrs });
  };
  
  const handleSaveTitle = () => {
      if (editedTitle.trim() !== '') {
          onUpdate({...goal, title: editedTitle });
          setIsEditing(false);
      }
  };

  const handleCancelEdit = () => {
      setEditedTitle(goal.title);
      setIsEditing(false);
  }


  return (
    <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-xl shadow-lg p-6 transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        {isEditing ? (
            <input 
                type="text"
                value={editedTitle}
                onChange={(e) => setEditedTitle(e.target.value)}
                className="text-2xl font-bold bg-transparent border-b-2 border-purple-500 w-full focus:outline-none text-slate-900 dark:text-white"
            />
        ) : (
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{goal.title}</h2>
        )}
        
        <div className="flex items-center space-x-2 flex-shrink-0 ml-4">
            {isEditing ? (
                <>
                    <button onClick={handleSaveTitle} className="text-green-500 hover:text-green-600"><SaveIcon /></button>
                    <button onClick={handleCancelEdit} className="text-slate-400 hover:text-slate-600"><CancelIcon /></button>
                </>
            ) : (
                <>
                    <button onClick={() => setIsEditing(true)} className="text-slate-400 hover:text-purple-500 dark:hover:text-purple-400 transition-colors">
                        <PencilIcon />
                    </button>
                    <button onClick={() => onDelete(goal.id)} className="text-slate-400 hover:text-red-500 dark:hover:text-red-400 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                    </button>
                </>
            )}
        </div>
      </div>

      <div className="flex items-center gap-4 mb-6">
        <ProgressBar progress={progress} />
        <span className="text-lg font-bold text-slate-700 dark:text-slate-200">{Math.round(progress)}%</span>
      </div>
      
      <div className="space-y-4">
        {goal.krs.length > 0 ? (
          goal.krs.map(kr => <KRCard key={kr.id} kr={kr} goal={goal} onUpdate={onUpdate} onDelete={handleDeleteKR} remainingWeightage={remainingWeightage} />)
        ) : (
          <div className="text-center py-8 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-lg">
             <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-300">Define Your Key Results</h3>
             <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">Break down your goal into measurable outcomes.</p>
          </div>
        )}
      </div>

      {remainingWeightage > 0 && (
         <button onClick={() => setIsKrModalOpen(true)} className="mt-6 w-full text-center py-2 px-4 border-2 border-dashed border-purple-400 text-purple-500 rounded-lg hover:bg-purple-50 dark:hover:bg-purple-900/50 hover:border-purple-500 transition-colors">
            + Add Key Result ({remainingWeightage}% remaining)
        </button>
      )}

      <Modal isOpen={isKrModalOpen} onClose={() => setIsKrModalOpen(false)} title="Add Key Result">
        <div className="space-y-4">
           <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
            <input type="text" value={newKrDesc} onChange={(e) => setNewKrDesc(e.target.value)} placeholder="e.g., 'Achieve 1000 daily active users'" className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Weightage (max {remainingWeightage}%)</label>
            <input type="number" value={newKrWeightage > 0 ? newKrWeightage : ''} onChange={(e) => setNewKrWeightage(Math.min(remainingWeightage, Number(e.target.value)))} max={remainingWeightage} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
          </div>
           <div className="flex justify-end">
            <button onClick={handleAddKR} className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-purple-300 disabled:cursor-not-allowed">Add</button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default GoalCard;