import React, { useState, useMemo, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'react-hot-toast';
import { Goal, KR, Initiative } from '../types';
import { Priority, Status } from '../constants';
import InitiativeCard from './InitiativeCard';
import ProgressBar from './ProgressBar';
import Modal from './Modal';
import { generateInitiativeSuggestions } from '../services/geminiService';
import { triggerConfetti } from '../utils/animations';

interface KRCardProps {
  kr: KR;
  goal: Goal;
  remainingWeightage: number;
  onUpdate: (updatedGoal: Goal) => void;
  onDelete: (krId: string) => void;
}

const PencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
        <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
    </svg>
);
const SaveIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
    </svg>
);
const CancelIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
    </svg>
);

const KRCard: React.FC<KRCardProps> = ({ kr, goal, remainingWeightage, onUpdate, onDelete }) => {
  const [isInitiativeModalOpen, setIsInitiativeModalOpen] = useState(false);
  const [newInitiativeDesc, setNewInitiativeDesc] = useState('');
  const [newInitiativePriority, setNewInitiativePriority] = useState<Priority>(Priority.Medium);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedKr, setEditedKr] = useState(kr);

  const calculateKRProgress = (initiatives: Initiative[]): number => {
    const totalPriority = initiatives.reduce((sum, i) => sum + i.priority, 0);
    if (totalPriority === 0) return 0;
    const completedPriority = initiatives
      .filter(i => i.status === Status.Completed)
      .reduce((sum, i) => sum + i.priority, 0);
    return (completedPriority / totalPriority) * 100;
  };

  const progress = useMemo(() => calculateKRProgress(kr.initiatives), [kr.initiatives]);
  
  // FIX: Explicitly initialize useRef with 0 to ensure its `current` property is always a number.
  // This might resolve a misleading downstream error.
  const prevProgressRef = useRef<number>(0);
  useEffect(() => {
    const roundedProgress = Math.round(progress);
    const roundedPrevProgress = Math.round(prevProgressRef.current);

    if (roundedPrevProgress < 100 && roundedProgress >= 100) {
        triggerConfetti();
        toast.success(`Key Result "${kr.description}" completed! 🎉`);
    }
    prevProgressRef.current = progress;
  }, [progress, kr.description]);

  const handleUpdateKR = (updatedKr: KR) => {
    const updatedKrs = goal.krs.map(k => k.id === updatedKr.id ? updatedKr : k);
    onUpdate({ ...goal, krs: updatedKrs });
  };
  
  const handleDeleteInitiative = (initiativeId: string) => {
      const updatedInitiatives = kr.initiatives.filter(i => i.id !== initiativeId);
      handleUpdateKR({ ...kr, initiatives: updatedInitiatives });
  };

  const handleAddInitiative = () => {
    if (newInitiativeDesc.trim() === '') return;
    const newInitiative: Initiative = {
      id: uuidv4(),
      description: newInitiativeDesc,
      priority: newInitiativePriority,
      status: Status.NotStarted,
    };
    handleUpdateKR({ ...kr, initiatives: [...kr.initiatives, newInitiative] });
    setNewInitiativeDesc('');
    setNewInitiativePriority(Priority.Medium);
    setIsInitiativeModalOpen(false);
  };

  const handleGenerateInitiatives = async () => {
    setIsAiLoading(true);
    try {
        const result = await generateInitiativeSuggestions(kr.description);
        if(result && result.initiatives.length > 0) {
            const newInitiatives = result.initiatives.map(i => ({
                id: uuidv4(),
                description: i.description,
                priority: Priority.Medium,
                status: Status.NotStarted
            }));
            handleUpdateKR({ ...kr, initiatives: [...kr.initiatives, ...newInitiatives] });
        }
    } catch (error) {
        console.error("Failed to generate initiatives:", error);
        toast.error('AI suggestion failed. Please try again.');
    } finally {
        setIsAiLoading(false);
        setIsInitiativeModalOpen(false);
    }
  };

  const handleSave = () => {
    handleUpdateKR(editedKr);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedKr(kr);
    setIsEditing(false);
  };

  const maxWeightage = remainingWeightage + kr.weightage;

  return (
    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-sm">
      <div className="flex justify-between items-start mb-3">
        {isEditing ? (
          <div className="flex-1 space-y-2">
            <input 
              type="text"
              value={editedKr.description}
              onChange={(e) => setEditedKr({...editedKr, description: e.target.value})}
              className="w-full px-2 py-1 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium text-slate-500 dark:text-slate-400">Weightage:</label>
              <input 
                type="number"
                value={editedKr.weightage > 0 ? editedKr.weightage : ''}
                max={maxWeightage}
                onChange={(e) => setEditedKr({...editedKr, weightage: Math.min(maxWeightage, Number(e.target.value))})}
                className="w-20 px-2 py-1 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <span className="text-sm text-slate-400">%</span>
            </div>
          </div>
        ) : (
          <div>
            <h4 className="font-semibold text-slate-800 dark:text-slate-100">{kr.description}</h4>
            <span className="text-sm font-medium text-slate-500 dark:text-slate-400">Weightage: {kr.weightage}%</span>
          </div>
        )}
        <div className="flex items-center space-x-1">
          {isEditing ? (
            <>
              <button onClick={handleSave} className="text-green-500 hover:text-green-600 p-1.5 rounded-full hover:bg-green-100 dark:hover:bg-green-900/50"><SaveIcon /></button>
              <button onClick={handleCancel} className="text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600"><CancelIcon /></button>
            </>
          ) : (
            <>
              <button onClick={() => setIsEditing(true)} className="text-slate-400 hover:text-purple-500 dark:hover:text-purple-400 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                <PencilIcon />
              </button>
              <button onClick={() => onDelete(kr.id)} className="text-slate-400 hover:text-red-500 dark:hover:text-red-400 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
                  </svg>
              </button>
            </>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-3 mb-4">
        <ProgressBar progress={progress} />
        <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">{Math.round(progress)}%</span>
      </div>

      <div className="space-y-2">
        {kr.initiatives.length > 0 ? (
          kr.initiatives.map(initiative => (
            <InitiativeCard key={initiative.id} initiative={initiative} kr={kr} onUpdate={handleUpdateKR} onDelete={handleDeleteInitiative} />
          ))
        ) : (
          <div className="text-center py-4 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-lg">
             <p className="text-sm text-slate-500 dark:text-slate-400">No initiatives yet. Add one to get started!</p>
          </div>
        )}
      </div>

      <button onClick={() => setIsInitiativeModalOpen(true)} className="mt-4 text-sm font-semibold text-purple-600 hover:text-purple-800 dark:text-purple-400 dark:hover:text-purple-300">+ Add Initiative</button>
      
      <Modal isOpen={isInitiativeModalOpen} onClose={() => setIsInitiativeModalOpen(false)} title="Add Initiative">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
            <input type="text" value={newInitiativeDesc} onChange={(e) => setNewInitiativeDesc(e.target.value)} placeholder="e.g., 'Complete the React course'" className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Priority</label>
            <select value={newInitiativePriority} onChange={(e) => setNewInitiativePriority(Number(e.target.value) as Priority)} className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option value={Priority.Low}>Low</option>
              <option value={Priority.Medium}>Medium</option>
              <option value={Priority.High}>High</option>
            </select>
          </div>
          <div className="flex justify-end space-x-3">
             <button onClick={handleGenerateInitiatives} disabled={isAiLoading} className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-purple-300 disabled:cursor-not-allowed transition-colors">
                {isAiLoading ? (
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm9 1a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1V3zM5 12a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zm9 1a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2z" clipRule="evenodd" /></svg>
                )}
                {isAiLoading ? 'Generating...' : 'Suggest Initiatives'}
            </button>
            <button onClick={handleAddInitiative} disabled={!newInitiativeDesc} className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 disabled:bg-purple-300 disabled:cursor-not-allowed">Add</button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default KRCard;