
import React from 'react';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth } from '../services/firebase';

const Auth: React.FC = () => {
  const handleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Authentication error:', error);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-900 px-4">
      <div className="max-w-md w-full text-center p-8 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold text-slate-800 dark:text-white mb-2">Welcome to Goally</h1>
        <p className="text-slate-500 dark:text-slate-400 mb-8">Achieve more with focused, measurable goals. Sign in to get started.</p>
        <button
          onClick={handleSignIn}
          className="w-full flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-transform transform hover:scale-105"
        >
          <svg className="w-5 h-5 mr-3" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512"><path fill="currentColor" d="M488 261.8C488 403.3 381.5 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 126 21.2 172.9 56.6l-67.4 66.8C314.6 94.6 283.4 80 248 80c-84.3 0-152.3 68.3-152.3 152S163.7 408 248 408c97.7 0 130.2-71.1 133.4-107.5H248V261.8h239.9c.1 8.2.1 16.4.1 24.4z"></path></svg>
          Sign In with Google
        </button>
      </div>
    </div>
  );
};

export default Auth;