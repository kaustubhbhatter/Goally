
import React from 'react';

interface ProgressBarProps {
  progress: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ progress }) => {
  const safeProgress = Math.min(100, Math.max(0, progress));

  const getColor = (p: number) => {
    if (p < 33) return 'bg-red-500';
    if (p < 66) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
      <div
        className={`h-2.5 rounded-full ${getColor(safeProgress)} transition-all duration-500 ease-out`}
        style={{ width: `${safeProgress}%` }}
      ></div>
    </div>
  );
};

export default ProgressBar;
   