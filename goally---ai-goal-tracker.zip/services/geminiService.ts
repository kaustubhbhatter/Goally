import { GoogleGenAI, Type } from "@google/genai";
import { KR } from "../types";

// FIX: Per coding guidelines, do not use 'as string' for the API key.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateGoalSuggestions = async (idea: string): Promise<{title: string} | null> => {
    try {
        const prompt = `Based on the user's idea: '${idea}', generate a SMART (Specific, Measurable, Achievable, Relevant, Time-bound) goal. Provide a concise 'title'. Respond in JSON format with one key: 'title'.`;
        
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                    },
                }
            }
        });

        // FIX: response.text can be undefined, add a check to prevent runtime error.
        const text = response.text;
        if (!text) {
            console.error('Error generating goal suggestions: Received empty response from API.');
            return null;
        }
        const jsonStr = text.trim();
        const result = JSON.parse(jsonStr);
        return result;

    } catch (error) {
        console.error('Error generating goal suggestions:', error);
        return null;
    }
};


export const generateInitiativeSuggestions = async (krDescription: string): Promise<{initiatives: {description: string}[]} | null> => {
     try {
        const prompt = `You are a helpful assistant for breaking down goals into actionable steps. For the key result: '${krDescription}', generate a list of 3 concrete initiatives to achieve it. For each initiative, provide a 'description'. Respond in JSON format with a key 'initiatives' which is an array of objects, each with a 'description' key.`;
        
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
             config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        initiatives: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    description: { type: Type.STRING }
                                }
                            }
                        }
                    },
                }
            }
        });
        
        // FIX: response.text can be undefined, add a check to prevent runtime error.
        const text = response.text;
        if (!text) {
            console.error('Error generating initiative suggestions: Received empty response from API.');
            return null;
        }
        const jsonStr = text.trim();
        const result = JSON.parse(jsonStr);
        return result;

    } catch (error) {
        console.error('Error generating initiative suggestions:', error);
        return null;
    }
}