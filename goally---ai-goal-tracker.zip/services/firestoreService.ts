
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, where } from 'firebase/firestore';
import { db } from './firebase';
import { Goal } from '../types';

const goalsCollection = collection(db, 'goals');

export const getGoals = async (userId: string): Promise<Goal[]> => {
  const q = query(goalsCollection, where('userId', '==', userId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Goal));
};

export const addGoal = async (goal: Omit<Goal, 'id'>): Promise<Goal | null> => {
  try {
    const docRef = await addDoc(goalsCollection, goal);
    return { id: docRef.id, ...goal };
  } catch (e) {
    console.error("Error adding document: ", e);
    return null;
  }
};

export const updateGoal = async (goal: Goal): Promise<void> => {
  const goalDoc = doc(db, 'goals', goal.id);
  // Firestore doesn't like the 'id' field in the data object
  const { id, ...goalData } = goal;
  await updateDoc(goalDoc, goalData);
};

export const deleteGoal = async (goalId: string): Promise<void> => {
  const goalDoc = doc(db, 'goals', goalId);
  await deleteDoc(goalDoc);
};
   