
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// IMPORTANT: Replace with your own Firebase project configuration
const firebaseConfig = {
  apiKey: "AIzaSyAYTTANU8bM8FZAiDoZEdyYKHT7Cj43L-Y",
  authDomain: "goally-dda53.firebaseapp.com",
  projectId: "goally-dda53",
  storageBucket: "goally-dda53.firebasestorage.app",
  messagingSenderId: "230771902995",
  appId: "1:230771902995:web:72b1513208c0c960600de6",
  measurementId: "G-0XJZ5VNGE3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };
   